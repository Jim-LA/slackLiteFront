import { Component } from '@angular/core';

@Component({
  selector: 'app-navbarpublic',
  standalone: true,
  imports: [],
  templateUrl: './navbarpublic.component.html',
  styleUrl: './navbarpublic.component.css'
})
export class NavbarpublicComponent {

}
