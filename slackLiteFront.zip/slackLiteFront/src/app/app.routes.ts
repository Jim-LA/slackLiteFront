import { Routes } from '@angular/router';
import { IndexComponent } from './Components/index/index.component';
import { MainMessagesComponent } from './Components/main-messages/main-messages.component';
import { MainChannelsComponent } from './Components/main-channels/main-channels.component';
import { MainUserComponent } from './Components/main-user/main-user.component';

export const routes: Routes = [
    { path: '', component: IndexComponent },
    { path: 'messages', component: MainMessagesComponent},
    { path: 'channels', component: MainChannelsComponent},
    { path: 'user', component: MainUserComponent}
    
];
