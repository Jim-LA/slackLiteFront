export enum ChannelStatus {
    INACTIVE = 0,
    ACTIVE = 1,
    LOCKED = 2,
}