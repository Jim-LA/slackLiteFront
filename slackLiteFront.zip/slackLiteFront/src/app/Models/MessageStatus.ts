export enum MessageStatus {
    INACTIVE = 0,
    ACTIVE = 1,
}
