export enum UserStatus {
    INACTIVE = 0,
    ACTIVE = 1,
}